document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelectorAll('.slider img');
    let currentSlide = 0;

    function showSlide(index) {
        slides.forEach((slide, i) => {
            slide.style.display = i === index ? 'block' : 'none'; // Asegura que solo una imagen esté visible
        });
    }

    function nextSlide() {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
    }

    // Inicializa el slider mostrando la primera imagen
    showSlide(currentSlide);

    // Cambia de imagen automáticamente cada 5 segundos
    setInterval(nextSlide, 5000);
});

let cart = [];

document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', function() {
        const product = this.getAttribute('data-product');
        cart.push(product);
        document.getElementById('cart-count').textContent = cart.length;
        updateCartModal();
    });
});

document.getElementById('cart-btn').addEventListener('click', function(e) {
    e.preventDefault();
    document.getElementById('cart-modal').style.display = 'block';
});

document.getElementById('close-cart').addEventListener('click', function() {
    document.getElementById('cart-modal').style.display = 'none';
});

function updateCartModal() {
    const cartItems = document.getElementById('cart-items');
    cartItems.innerHTML = '';
    cart.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item;
        cartItems.appendChild(li);
    });
}
