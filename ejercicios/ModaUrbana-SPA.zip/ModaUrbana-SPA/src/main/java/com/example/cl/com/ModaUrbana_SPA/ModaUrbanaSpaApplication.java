package com.example.cl.com.ModaUrbana_SPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModaUrbanaSpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModaUrbanaSpaApplication.class, args);
	}

}
