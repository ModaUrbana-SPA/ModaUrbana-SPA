package com.example.cl.com.ModaUrbana_SPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModaUrbanaSpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
