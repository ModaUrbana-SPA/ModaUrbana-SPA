# spring-auth
Repositorio Spring con ejemplo de persistencia de datos, estructura CSR (MVC) y Autorización
